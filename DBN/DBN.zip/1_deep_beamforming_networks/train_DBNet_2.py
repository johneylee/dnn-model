import numpy as np
import torch
import os
import time
import ssplib
from DBNet_2 import DBNet


def gen_batch(noisy_list, idx=0):
    gccphat = torch.tensor(np.load(noisy_list[idx] + '.gccphat.npy'), dtype=torch.float32).to(device)
    gccphat = gccphat.reshape(gccphat.shape[0], -1)
    phnlabel = np.load(noisy_list[idx] + '.phnlabel.npy')
    phnlabel = torch.tensor(np.argmax(phnlabel, 1), dtype=torch.long).to(device)
    mch_stft = np.load(noisy_list[idx] + '.noisyMchSTFT.npy')

    bi = gccphat
    bi2 = mch_stft
    bo = phnlabel

    idx += 1  # next utterance

    return bi, bi2, bo, idx, gccphat.shape[0]


model_name = 'original_DBNet_39phn_online'  # name of test to save
model_dir = os.path.join('DNN_model', model_name)
ssplib.make_sure_path_exists(model_dir)

fs = 16000
frame_time = 32
frame_size = int(fs*frame_time/1000)

c = 340
mic_num = 8
mic_dist = 0.08
mic_array = np.linspace(0, (mic_num-1)*mic_dist, mic_num).reshape([-1, 1])
max_delay = int(np.ceil((mic_num - 1) * mic_dist / c * fs))

device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
model = DBNet(mic_num, max_delay, frame_size, nfbank=40)
model.to(device)

epoch_num = 100
train_noisy_list = ssplib.read_txt_file('train_noisy_list.txt')
# train_noisy_list = ssplib.read_txt_file('test_noisy_debug_list.txt')
train_num = int(1e4)  # number of utterance for training
val_num = int(1e3)  # number of utterance for validation

print("Device: {}".format(device))
print("Model's state_dict:")
for param_tensor in model.state_dict():
    print(param_tensor, "\t", model.state_dict()[param_tensor].size())
print("# of model parameters: {}".format(ssplib.count_parameters(model)))

train_list = train_noisy_list[0:train_num]
val_list = train_noisy_list[train_num:train_num + val_num]

criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)

train_cost = np.zeros(epoch_num)
val_cost = np.zeros(epoch_num)
val_accuracy = np.zeros(epoch_num)
for epoch in range(epoch_num):
    np.random.shuffle(train_list)
    np.random.shuffle(val_list)

    # Training
    start_time = time.time()
    model.train()
    list_idx = 0
    train_cost_temp = []
    while list_idx < train_num:  # train_num:  # used number of utterance  < total number of utterance
        batch_in, batch_in2, batch_out, list_idx, _ = gen_batch(noisy_list=train_list, idx=list_idx)
        y_pred, _, _ = model(batch_in, batch_in2)  # Forward pass: Compute predicted y by passing x to the model
        train_cost_batch = criterion(y_pred, batch_out)  # Compute loss
        optimizer.zero_grad()  # Zero gradients, perform a backward pass, and update the weights.
        train_cost_batch.backward()
        optimizer.step()
        train_cost_temp.append(train_cost_batch.data.to('cpu'))

    train_cost[epoch] = sum(train_cost_temp) * 1.0 / len(train_cost_temp)
    np.savetxt(os.path.join(model_dir, 'train_cost.txt'), train_cost)

    # Validate
    model.eval()
    list_idx = 0
    val_cost_temp = []
    val_accuracy_temp = []
    val_nframe = 0
    while list_idx < val_num:
        batch_in, batch_in2, batch_out, list_idx, nframe = gen_batch(noisy_list=val_list, idx=list_idx)
        y_pred, _, _ = model(batch_in, batch_in2)  # Forward pass: Compute predicted y by passing x to the model
        val_cost_batch = criterion(y_pred, batch_out)  # Compute loss
        pred = y_pred.argmax(dim=1, keepdim=True)  # get the index of the max log-probability
        val_accuracy_batch = pred.eq(batch_out.view_as(pred)).sum().item()
        val_cost_temp.append(val_cost_batch.data.to('cpu'))
        val_accuracy_temp.append(val_accuracy_batch)
        val_nframe += nframe

    val_cost[epoch] = sum(val_cost_temp) * 1.0 / len(val_cost_temp)
    val_accuracy[epoch] = 100.0 * sum(val_accuracy_temp) / val_nframe  # devided by total nframe
    np.savetxt(os.path.join(model_dir, 'val_cost.txt'), val_cost)
    np.savetxt(os.path.join(model_dir, 'val_accuracy.txt'), val_accuracy)

    end_time = time.time()

    print("[Epoch: {}]  train_cost={:.4f}  val_cost={:.4f}  val_accuracy={:.2f}  time={}"
          .format(epoch, train_cost[epoch], val_cost[epoch], val_accuracy[epoch], int(end_time - start_time)))

    # save model and output result
    if epoch % 10 == 0:
        ssplib.make_sure_path_exists(os.path.join(model_dir, str(epoch)))
        torch.save(model.state_dict(), os.path.join(model_dir, str(epoch), 'model{}.pth.tar'.format(epoch)))
print('--Training is finished--')

abstime = time.localtime()
print('End time: {}.{}.{} {}:{}:{}'.format(abstime.tm_year, abstime.tm_mon, abstime.tm_mday,
                                           abstime.tm_hour, abstime.tm_min, abstime.tm_sec))
min_epoch = np.argmin(val_cost[0:epoch_num:10])*10
print('epoch which has minimum val_cost: ' + str(min_epoch))

