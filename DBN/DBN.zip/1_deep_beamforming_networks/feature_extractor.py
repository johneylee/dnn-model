import numpy as np
import itertools
import scipy.io.wavfile as wav
import time
import os
import random
import ssplib


def get_timit_dict(dic_location):
    # read file with all phonemes (silences are all in line 61)
    file_obj = open(dic_location, 'r')
    phonem_assigment = file_obj.readlines()
    file_obj.close()

    phonemlist_length = phonem_assigment.__len__()
    max_phonem_length = 39 -1  # -1 for array
    # create key value dictionary
    dict_timit = {}
    for i in range(phonemlist_length):
        symbol = phonem_assigment[i].split(" ")
        symbol = symbol[0].split("\n")[0]
        dict_timit[symbol] = min(i, max_phonem_length)
    return dict_timit


def get_phn_label(phn_location, dict_timit, input_size, frame_time):
    phn_file = open(phn_location, 'r')
    phn_position = phn_file.readlines()
    phn_file.close()

    phn_position_length = phn_position.__len__() - 1
    target = np.empty([input_size, 39])

    # 61 to 39 mapping
    with open("phones.60-48-39.map", 'r') as fid:
        lines = (l.strip().split() for l in fid)
        lines = [l for l in lines if len(l) == 3]
    for i in range(len(lines)):
        lines[i].pop(1)
    map_61_39 = dict(lines)

    # get first phoneme
    phn_count = 0
    low_bound, high_bound, symbol = phn_position[phn_count].split(" ")
    high_bound = int(high_bound)
    high_bound_ms = high_bound * 0.0625
    symbol = map_61_39[symbol.rstrip()]

    # go step by step through target vector and add phoneme vector
    for i in range(input_size):
        threshold = frame_time/2 + i * frame_time/2
        if high_bound_ms > threshold:
            tarray = np.zeros(39)
            tarray[dict_timit[symbol]] = 1
            target[i] = tarray
        else:
            # get next phoneme
            phn_count = min(phn_count + 1, phn_position_length)
            low_bound, high_bound, symbol = phn_position[phn_count].split(" ")
            high_bound = int(high_bound)
            high_bound_ms = high_bound * 0.0625
            symbol = symbol.rstrip()

            # 61 to 39
            tarray = np.zeros(39)
            symbol = map_61_39[symbol]
            tarray[dict_timit[symbol]] = 1
            target[i] = tarray
    return target


def add_noise(sig, noise, snr):
    ibgn = random.randint(0, len(noise)-len(sig))
    noise = np.array(noise[ibgn:ibgn+len(sig)])

    # scaling factor calculation
    p_sig = np.mean(np.square(sig))
    p_noise = np.mean(np.square(noise))
    scale_factor = np.sqrt((p_sig / np.power(10, snr / 10)) / p_noise)

    sig_stft = ssplib.stft(sig, frame_size=frame_size, overlap_factor=0.5, fft_size=frame_size)
    sig_mch_stft = ssplib.gen_array_signal(sig_stft, mic_array, np.pi / 2, fs)
    noise_stft = ssplib.stft(noise, frame_size=frame_size, overlap_factor=0.5, fft_size=frame_size)
    noise_mch_stft = ssplib.gen_array_signal(noise_stft*scale_factor, mic_array, 2*np.pi/36*random.randint(1, 36), fs)

    # add noise to the signal according to the SNR
    noisy_mch_stft = sig_mch_stft + noise_mch_stft
    return noisy_mch_stft


def save_multichannel_train_noisy_speech(snr, ntype, rep, noise_dir, target_list, target_dir):
    for n in range(0, rep):
        start_time = time.time()
        for m in range(0, len(target_list)):
            snr_chosen = random.choice(snr)
            ntype_chosen = random.choice(ntype)
            save_dir = os.path.join(target_dir, ntype_chosen, str(snr_chosen) + 'dB')
            name = target_list[m].split('/')
            save_name = os.path.join(save_dir, name[-3] + '_' + name[-2] + '_' + name[-1] + '.noisyMchSTFT')
            while os.path.exists(save_name + '.npy'):
                snr_chosen = random.choice(snr)
                ntype_chosen = random.choice(ntype)
                save_dir = os.path.join(target_dir, ntype_chosen, str(snr_chosen) + 'dB')
                name = target_list[m].split('/')
                save_name = os.path.join(save_dir, name[-3] + '_' + name[-2] + '_' + name[-1] + '.noisyMchSTFT')
            ssplib.make_sure_path_exists(save_dir)
            _, speech = wav.read(target_list[m] + '.wav')  # load speech wav
            speech = speech / 32768
            _, noise = wav.read(os.path.join(noise_dir, ntype_chosen + '.wav'))  # load noise wav
            noise = noise / 32768
            noisy_mch_stft = add_noise(speech, noise, snr_chosen)
            np.save(save_name, noisy_mch_stft)
        end_time = time.time()  # TIMIT/DR1/FCJF0/SI648.wav => TIMIT_noisy/factory/5dB/DR1_FCJF0_SI648.wav
        print('Noisy DB (' + str(n) + '/' + str(rep) + ') complete, time: ' + str(end_time - start_time))


def save_multichannel_noisy_speech(snr, ntype, noise_dir, target_list, target_dir):
    for l in range(0, len(ntype)):
        _, noise = wav.read(os.path.join(noise_dir, ntype[l] + '.wav'))  # load noise wav
        noise = noise / 32768
        start_time = time.time()
        for m in range(0, len(snr)):
            save_dir = os.path.join(target_dir, ntype[l], str(snr[m]) + 'dB')  # make noisy dir. ex) TIMIT_noisy/factory/5dB
            ssplib.make_sure_path_exists(save_dir)
            for n in range(0, len(target_list)):
                _, speech = wav.read(target_list[n] + '.wav')  # load speech wav
                speech = speech / 32768
                noisy_mch_stft = add_noise(speech, noise, snr[m])
                name = target_list[n].split('/')
                np.save(os.path.join(save_dir, name[-3] + '_' + name[-2] + '_' + name[-1]) + '.noisyMchSTFT', noisy_mch_stft)
        end_time = time.time()
        print('Noisy DB complete: ' + ntype[l] + ' time: ' + str(end_time - start_time))


def extract_features(noisy_list, clean_dir, frame_size):
    print('==== Extract features =====')
    array_comb = list(itertools.combinations(range(mic_num), 2))
    for n in range(len(noisy_list)):
        noisy_mch_stft = np.load(noisy_list[n] + '.noisyMchSTFT.npy')
        gccphat = np.zeros((noisy_mch_stft.shape[0], len(array_comb), frame_size))
        max_delay = int(np.ceil((mic_num - 1) * mic_dist / c * fs))
        for m in range(len(array_comb)):
            idx0 = array_comb[m][0]
            idx1 = array_comb[m][1]
            gccphat[:, m] = ssplib.gen_gcc_phat(noisy_mch_stft[:, idx0, :], noisy_mch_stft[:, idx1, :])
        gccphat = gccphat[:, :, int(frame_size / 2) - max_delay - 1:int(frame_size / 2) + max_delay]
        np.save(noisy_list[n] + '.gccphat', gccphat)

        name = noisy_list[n].split('/')[-1]
        name2 = os.path.join(clean_dir, name.split('_')[-3], name.split('_')[-2], name.split('_')[-1]) + '.PHN'
        timit_dict = get_timit_dict('phonemlist')
        phn_label = get_phn_label(name2,  timit_dict, noisy_mch_stft.shape[0], frame_time)
        np.save(noisy_list[n] + '.phnlabel', phn_label)


def gen_list():
    print('==== Generate lists =====')
    train_list = ssplib.find_files(clean_train_dir, '*.wav')
    ssplib.list_to_txt_file('train_list.txt', train_list)

    test_list = ssplib.find_files(clean_test_dir, '*.wav')
    ssplib.list_to_txt_file('test_list.txt', test_list)


def gen_database():
    print('==== Generate database =====')
    train_list = ssplib.read_txt_file('train_list.txt')
    save_multichannel_train_noisy_speech(snr[0:5], ntype[0:4], 3, noise_train_dir, train_list,
                                         os.path.join(private_DB_dir, 'TIMIT_noisy', 'TRAIN'))
    train_noisy_list = ssplib.find_files(noisy_train_dir, '*.noisyMchSTFT.*')
    ssplib.list_to_txt_file('train_noisy_list.txt', train_noisy_list)

    test_list = ssplib.read_txt_file('test_list.txt')
    save_multichannel_noisy_speech(snr[0:5], ntype[0:6], noise_test_dir, test_list,
                                   os.path.join(private_DB_dir, 'TIMIT_noisy', 'TEST_CORE'))
    test_noisy_list = ssplib.find_files(noisy_test_dir, '*.noisyMchSTFT.*')
    ssplib.list_to_txt_file('test_noisy_list.txt', test_noisy_list)


def extract_clean_features(clean_dir):
    clean_list = ssplib.find_files(clean_dir, '*.wav')
    private_dir = os.path.join(private_DB_dir, 'TIMIT/TRAIN')
    for n in range(len(clean_list)):
        _, speech = wav.read(clean_list[n] + '.wav')
        speech = speech/32768
        clean_stft = ssplib.stft(speech, frame_size=frame_size, overlap_factor=0.5, fft_size=frame_size)
        save_name = os.path.join(private_dir, '_'.join(clean_list[n].split('/')[-3:])) + '.stft'
        ssplib.make_sure_path_exists(os.path.dirname(save_name))
        np.save(save_name, clean_stft)


def gen_0ch_noisy_wav():
    noisy_list = ssplib.read_txt_file('test_noisy_list.txt')
    for n in range(len(noisy_list)):
        noisy_mch_stft = np.load(noisy_list[n] + '.noisyMchSTFT.npy')
        noisy_speech = ssplib.istft(noisy_mch_stft[:, 0, :], frame_size, 0.5).astype('f')
        wav.write(noisy_list[n] + '.wav', fs, np.asarray(noisy_speech * 32768, dtype=np.int16))


# DB_dir = '/Users/jinyoung/Storage/1_Study/12_LG_harshnoise/Coding/DB/'  # macbook
public_DB_dir = '/home/jinyoung/Storage/DB'  # server
private_DB_dir = '/home/jinyoung/Storage/12_LG_harshnoise/DB'  # server
clean_train_dir = os.path.join(public_DB_dir, 'TIMIT/TRAIN')
clean_test_dir = os.path.join(public_DB_dir, 'TIMIT/TEST_CORE')
noise_train_dir = os.path.join(public_DB_dir, 'noise_16k/TRAIN')
noise_test_dir = os.path.join(public_DB_dir, 'noise_16k/TEST')
noisy_train_dir = os.path.join(private_DB_dir, 'TIMIT_noisy/TRAIN')
noisy_test_dir = os.path.join(private_DB_dir, 'TIMIT_noisy/TEST_CORE')


fs = 16000
frame_time = 32
frame_size = int(fs*frame_time/1000)

c = 340
mic_num = 8
mic_dist = 0.08
mic_array = np.linspace(0, (mic_num-1)*mic_dist, mic_num).reshape([-1, 1])

snr = [10, 5, 0, -5, -10]
ntype = ["babble", "white", "factory1", "aurora4_restaurant_1", "destroyerengine", "aurora4_exhibition_1"]

# gen_list()
# gen_database()

# train_noisy_list = ssplib.read_txt_file('train_noisy_list.txt')
# test_noisy_list = ssplib.read_txt_file('test_noisy_list.txt')
# extract_features(train_noisy_list, clean_train_dir, frame_size)
# extract_features(test_noisy_list, clean_test_dir, frame_size)

# extract_clean_features(clean_train_dir)
# extract_clean_features(clean_test_dir)
gen_0ch_noisy_wav()
