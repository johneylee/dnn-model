import numpy as np
import torch
import os
import scipy.io.wavfile as wav
import ssplib
from DBNet_2 import DBNet


def gen_batch(noisy_list, idx=0):
    gccphat = torch.tensor(np.load(noisy_list[idx] + '.gccphat.npy'), dtype=torch.float32).to(device)
    gccphat = gccphat.reshape(gccphat.shape[0], -1)
    phnlabel = np.load(noisy_list[idx] + '.phnlabel.npy')
    phnlabel = torch.tensor(np.argmax(phnlabel, 1), dtype=torch.long).to(device)
    mch_stft = np.load(noisy_list[idx] + '.noisyMchSTFT.npy')
    bi = gccphat
    bi2 = mch_stft
    bo = phnlabel
    idx += 1  # next utterance
    return bi, bi2, bo, idx


model_name = 'mtl_DBNet_39phn'  # name of test to save
model_dir = os.path.join('DNN_model', model_name)
test_name = 'TEST_CORE'
result_dir = os.path.join(model_dir, 'DNN_test', test_name)
project_dir = os.getcwd()
ssplib.make_sure_path_exists(result_dir)

fs = 16000
frame_time = 32
frame_size = int(fs*frame_time/1000)

c = 340
mic_num = 8
mic_dist = 0.08
mic_array = np.linspace(0, (mic_num-1)*mic_dist, mic_num).reshape([-1, 1])
max_delay = int(np.ceil((mic_num - 1) * mic_dist / c * fs))

epoch_num = 81
val_cost = np.loadtxt(model_dir + '/val_cost.txt')
min_epoch = np.argmin(val_cost[0:epoch_num:10])*10

list_name = 'test_noisy_list.txt'
test_list = ssplib.read_txt_file(list_name)
test_num = len(test_list)

device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
model = DBNet(mic_num, max_delay, frame_size, nfbank=40)
model.to(device)

model.load_state_dict(torch.load(model_dir + '/{}/model{}.pth.tar'.format(min_epoch, min_epoch)))
model.eval()

print('test model epoch: ' + str(min_epoch))
print('test model dir: ' + model_dir + '/{}/model{}.pth.tar'.format(min_epoch, min_epoch))
print("Device: {}".format(device))
# print("Model's state_dict:")
# for param_tensor in model.state_dict():
#     print(param_tensor, "\t", model.state_dict()[param_tensor].size())
print("# of model parameters: {}".format(ssplib.count_parameters(model)))

list_idx = 0
criterion = torch.nn.CrossEntropyLoss()
test_accuracy_temp = []
enhanced_wav_list = []
nframe = 0
while list_idx < test_num:
    batch_in, batch_in2, batch_out, list_idx = gen_batch(noisy_list=test_list, idx=list_idx)
    y_pred, _, beamformed_stft = model(batch_in, batch_in2)  # Forward pass: Compute predicted y by passing x to the model

    pred = y_pred.argmax(dim=1, keepdim=True)  # get the index of the max log-probability
    test_accuracy_batch = pred.eq(batch_out.view_as(pred)).sum().item()
    test_accuracy_temp.append(test_accuracy_batch)

    beamformed_stft = np.array(beamformed_stft.data.to('cpu'))  # 2 * nframe * 257
    enhanced_stft = beamformed_stft[0] + beamformed_stft[1]*1j
    nframe += beamformed_stft.shape[1]
    enhanced_speech = ssplib.istft(enhanced_stft, frame_size, 0.5).astype('f')
    # enhanced_speech = enhanced_speech / np.max(np.abs(enhanced_speech)) * 0.5

    name = test_list[list_idx - 1] + '_e.wav'
    name2 = os.path.join(result_dir, name.split('/')[-3], name.split('/')[-2], name.split('/')[-1])
    ssplib.make_sure_path_exists(os.path.dirname(name2))
    wav.write(name2, fs, np.asarray(enhanced_speech * 32768, dtype=np.int16))
    enhanced_wav_list.append(os.path.join(project_dir, name2))
    print('{}: {}'.format(list_idx - 1, name2))

test_accuracy = 100.0 * sum(test_accuracy_temp) / nframe
# ssplib.list_to_txt_file(os.path.join(result_dir, 'enhanced_wav_list.txt'), enhanced_wav_list)
print('test accuracy: {}'.format(test_accuracy))
print('--Test is finished--')


