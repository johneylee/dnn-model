import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import librosa
import itertools

# utterance level training. all same with paper except pre-training


class DBNet(nn.Module):
    def __init__(self, mic_num, max_delay, frame_size, nfbank):
        super(DBNet, self).__init__()
        self.mic_num = mic_num
        self.frame_size = frame_size
        self.nfbank = nfbank
        array_comb = list(itertools.combinations(range(mic_num), 2))
        self.fc1 = nn.Linear(len(array_comb)*(max_delay*2+1), 1024)
        self.fc2 = nn.Linear(1024, 1024)
        self.fc3 = nn.Linear(1024, int(mic_num*2*(frame_size/2+1)))

        self.fc4 = nn.Linear(nfbank*3*11, 2048)
        self.fc5 = nn.Linear(2048, 2048)
        self.fc6 = nn.Linear(2048, 2048)
        self.fc7 = nn.Linear(2048, 2048)
        self.fc8 = nn.Linear(2048, 2048)
        self.fc9 = nn.Linear(2048, 2048)
        self.fc10 = nn.Linear(2048, 39)

    def forward(self, x, mch_stft): # number of utterance x frame x dimension
        x = torch.sigmoid(self.fc1(x))
        x = torch.sigmoid(self.fc2(x))
        x = torch.sigmoid(self.fc3(x))

        # mean pooling
        w = x.reshape(2, x.shape[0], self.mic_num, -1)  # weights 2 * nframe * 8 * 257
        w = torch.mean(w, 1)  # weights 2 * 8 * 257

        device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
        float_stft = torch.zeros(2, mch_stft.shape[0], mch_stft.shape[1], mch_stft.shape[2]).to(device)
        float_stft[0] = torch.tensor(np.real(mch_stft), dtype=torch.float32)
        float_stft[1] = torch.tensor(np.imag(mch_stft), dtype=torch.float32)  # 2 * nframe * 8 * 257

        # beamforming
        beamformed_stft = torch.zeros(2, mch_stft.shape[0], mch_stft.shape[1], mch_stft.shape[2])
        beamformed_stft[0] = w[0] * float_stft[0] - w[1] * float_stft[1]
        beamformed_stft[1] = w[0] * float_stft[1] + w[1] * float_stft[0]
        beamformed_stft = torch.sum(beamformed_stft, 2)  # 2 * nframe * 257

        # mel filtering
        melfb = torch.tensor(librosa.filters.mel(16000, self.frame_size, self.nfbank), dtype=torch.float32)  # 40 * 257
        x = (beamformed_stft[0] ** 2 + beamformed_stft[1] ** 2) / self.frame_size  # complex power spectrum nframe * 257
        x = torch.log10(x @ torch.t(melfb))  # nframe * 40

        # utterance-level mean normalization
        x = x - torch.mean(x)

        x_temp = x[:, :-1]
        xdel = torch.zeros(x.shape)
        xdel[:, 1:] = x[:, 1:] - x_temp

        x_temp = xdel[:, :-1]
        xdeldel = torch.zeros(x.shape)
        xdeldel[:, 1:] = xdel[:, 1:] - x_temp

        x = torch.cat((x, xdel, xdeldel), 1).to(device)  # nframe * 120
        cs = 5
        ctxt_feature = torch.zeros(x.shape[0], x.shape[1] * (2 * cs + 1)).to(device)
        for m in range(0, x.shape[0]):
            if m < cs+1:
                ctxt_feature[m] = torch.cat((torch.zeros(cs-m, x.shape[1]).to(device), x[0:cs+m+1]), 0).reshape(1, -1)[0]
            elif m > x.shape[0]-cs-1:
                ctxt_feature[m] = torch.cat((x[m-cs:], torch.zeros(m-x.shape[0]+cs+1, x.shape[1]).to(device)), 0).reshape(1, -1)[0]
            else:
                ctxt_feature[m] = x[m-cs:m+cs+1].reshape(1, -1)[0]
        x = torch.sigmoid(self.fc4(ctxt_feature))  # nframe * 1320
        x = torch.sigmoid(self.fc5(x))
        x = torch.sigmoid(self.fc6(x))
        x = torch.sigmoid(self.fc7(x))
        x = torch.sigmoid(self.fc8(x))
        x = torch.sigmoid(self.fc9(x))
        x = self.fc10(x)

        return F.log_softmax(x, dim=1), w, beamformed_stft
