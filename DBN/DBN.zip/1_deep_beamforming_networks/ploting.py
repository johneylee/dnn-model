import numpy as np
import os
import matplotlib.pyplot as plt
import scipy.io.wavfile as wav


def learning_curve():
    train_cost = np.loadtxt(os.path.join(model_dir, 'train_cost.txt'))
    val_cost = np.loadtxt(os.path.join(model_dir, 'val_cost.txt'))
    val_accuracy = np.loadtxt(os.path.join(model_dir, 'val_accuracy.txt'))
    plt.plot(train_cost)
    plt.plot(val_cost)
    plt.xlabel('Epoch')
    plt.ylabel('Cross entropy')
    plt.xlim([0, train_cost.shape[0]])
    plt.legend(['train', 'validation'])
    plt.grid()
    plt.show()

    # fig, ax1 = plt.subplots()
    #
    # color = 'tab:blue'
    # ax1.set_xlabel('time (s)')
    # ax1.set_ylabel('cross entropy', color=color)
    # ax1.plot(train_cost, color=color)
    # ax1.plot(val_cost, color='tab:orange')
    # ax1.tick_params(axis='y', labelcolor=color)
    #
    # ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis
    # color = 'tab:red'
    # ax2.set_ylabel('accuracy', color=color)  # we already handled the x-label with ax1
    # ax2.plot(val_accuracy, color=color)
    # ax2.tick_params(axis='y', labelcolor=color)
    #
    # fig.tight_layout()  # otherwise the right y-label is slightly clipped
    # plt.show()


def spectrogram():
    fs = 16000
    vmin = -150
    vmax = -40
    name = target_wav.split('.')[0].split('/')
    name = '_'.join(name)
    _, speech = wav.read(os.path.join(result_dir, target_wav))
    powerSpectrum, freqenciesFound, time, imageAxis = plt.specgram(speech/32768, NFFT=1024, Fs=fs, window=np.blackman(1024),
                                                                   noverlap=768, cmap='jet', vmin=vmin, vmax=vmax)
    # plt.colorbar(imageAxis)  # cbar
    plt.xlim(time[0], time[-1])
    plt.xlabel('Time (sec)', fontsize=16)
    plt.ylabel('Frequency (Hz)', fontsize=16)
    plt.savefig(os.path.join(target_dir, 'DBNet_'+name+'.png'), dpi=300)
    plt.show()

    _, speech = wav.read(os.path.join(result_dir2, target_wav))
    powerSpectrum, freqenciesFound, time, imageAxis = plt.specgram(speech/32768, NFFT=1024, Fs=fs, window=np.blackman(1024),
                                                                   noverlap=768, cmap='jet', vmin=vmin, vmax=vmax)
    # plt.colorbar(imageAxis)
    plt.xlim(time[0], time[-1])
    plt.xlabel('Time (sec)', fontsize=16)
    plt.ylabel('Frequency (Hz)', fontsize=16)
    plt.savefig(os.path.join(target_dir, 'DSB_'+name+'.png'), dpi=300)
    plt.show()

    _, speech = wav.read(os.path.join(result_dir3, target_wav))
    powerSpectrum, freqenciesFound, time, imageAxis = plt.specgram(speech/32768, NFFT=1024, Fs=fs, window=np.blackman(1024),
                                                                   noverlap=768, cmap='jet', vmin=vmin, vmax=vmax)
    # plt.colorbar(imageAxis)
    plt.xlim(time[0], time[-1])
    plt.xlabel('Time (sec)', fontsize=16)
    plt.ylabel('Frequency (Hz)', fontsize=16)
    plt.savefig(os.path.join(target_dir, 'MVDR_'+name+'.png'), dpi=300)
    plt.show()


def save_wav():
    fs = 16000
    name = target_wav.split('/')
    name = '_'.join(name)
    _, noisy = wav.read(noisy_dir + target_wav.split('_e.')[0] + '.wav')
    noisy = noisy/32768
    p_noisy = np.sum(np.square(noisy))
    wav.write(os.path.join(target_dir, 'noisy_'+name), fs, np.asarray(noisy*32768*2, dtype=np.int16))

    _, speech = wav.read(os.path.join(result_dir, target_wav))
    speech = speech/32768
    p_speech = np.sum(np.square(speech))
    alpha = np.sqrt(p_noisy/p_speech)
    wav.write(os.path.join(target_dir, 'DBNet_'+name), fs, np.asarray(speech*alpha*32768*2, dtype=np.int16))
    print(p_noisy, p_speech, alpha)

    _, speech = wav.read(os.path.join(result_dir_, target_wav))
    speech = speech/32768
    p_speech = np.sum(np.square(speech))
    alpha = np.sqrt(p_noisy/p_speech)
    wav.write(os.path.join(target_dir, 'DBNet_mult_'+name), fs, np.asarray(speech*alpha*32768*2, dtype=np.int16))
    print(p_noisy, p_speech, alpha)

    _, speech = wav.read(os.path.join(result_dir2, target_wav))
    speech = speech/32768
    p_speech = np.sum(np.square(speech))
    alpha = np.sqrt(p_noisy/p_speech)
    wav.write(os.path.join(target_dir, 'DSB_'+name), fs, np.asarray(speech*alpha*32768*2, dtype=np.int16))
    print(p_noisy, p_speech, alpha)

    _, speech = wav.read(os.path.join(result_dir3, target_wav))
    speech = speech/32768
    p_speech = np.sum(np.square(speech))
    alpha = np.sqrt(p_noisy/p_speech)
    wav.write(os.path.join(target_dir, 'MVDR_'+name), fs, np.asarray(speech*alpha*32768*2, dtype=np.int16))
    print(p_noisy, p_speech, alpha)


noisy_dir = '../DB/TIMIT_noisy/TEST_CORE/'

model_name = 'original_DBNet_39phn_online'  # name of test to save
model_dir = os.path.join('DNN_model', model_name)
model_name_ = 'mtl_DBNet_39phn'  # name of test to save
model_dir_ = os.path.join('DNN_model', model_name_)
model_name2 = 'delay_and_sum'
model_dir2 = os.path.join('Statistical', model_name2)
model_name3 = 'MVDR_sl_eye'
model_dir3 = os.path.join('Statistical', model_name3)
test_name = 'TEST_CORE'

result_dir = os.path.join(model_dir, 'DNN_test', test_name)
result_dir_ = os.path.join(model_dir_, 'DNN_test', test_name)
result_dir2 = os.path.join(model_dir2, test_name)
result_dir3 = os.path.join(model_dir3, test_name)

target_dir = 'figure/0813'

target_wav = 'aurora4_exhibition_1/-5dB/DR2_FPAS0_SI944_e.wav'
# spectrogram()
save_wav()
